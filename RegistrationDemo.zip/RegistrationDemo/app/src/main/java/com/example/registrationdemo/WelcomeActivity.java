package com.example.registrationdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {

    TextView nameTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome2);

        nameTv = (TextView)findViewById(R.id.nametv);

        Bundle bundle = getIntent().getExtras();
        String name = bundle.getString("namekey");

        nameTv.setText("welcome "+name);
    }
}