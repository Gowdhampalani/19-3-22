package com.example.registrationdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.registrationdemo.R.layout.demo;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText usernameEt,lastnameEt;
    Button clearBtn,submitBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        usernameEt = (EditText)  findViewById(R.id.usenameet);
        lastnameEt = (EditText) findViewById(R.id.lastnameet);
        clearBtn = (Button) findViewById(R.id.clearbtn);
        submitBtn = (Button) findViewById(R.id.submitbtn);

        clearBtn.setOnClickListener(this);
        submitBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.clearbtn: clearAll();
            break;
            case R.id.submitbtn: submitAll();
            break;
        }



}

    private void clearAll()
    {
        usernameEt.setText(" ");
        lastnameEt.setText(" ");
        usernameEt.requestFocus();
    }

    private void submitAll()
    {
        // Click Event Code
        String username = usernameEt.getText().toString();
        String lastname = lastnameEt.getText().toString();

        //Toast
        Toast.makeText(MainActivity.this,username+" "+lastname,Toast.LENGTH_LONG).show();

        Intent intent = new Intent(MainActivity.this,WelcomeActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("namekey",username);
        intent.putExtras(bundle);

        startActivity(intent);
    }
    }